-- Lua implementation of JSON.
-- See http://www.json.org/
--
-- Copyright (c) 2005-2007 by Douglas Crockford.

local function type (o)
    if o == nil then
        return "nil"
    end
    local t = getmetatable(o)
    if t and t.__type then
        return t.__type
    end
    return type(o)
end

local function is_array (t)
    local i = 0
    for _ in pairs(t) do
        i = i + 1
        if t[i] == nil then
            return false
        end
    end
    return true
end

local function is_empty (t)
    for _ in pairs(t) do
        return false
    end
    return true
end

local function encode_string (s)
    local str = s:gsub("([\"\\])", "\\%1")
    str = str:gsub("[\n]", "\\n")
    str = str:gsub("[\r]", "\\r")
    str = str:gsub("[\t]", "\\t")
    return '"' .. str .. '"'
end

local function encode_array (t)
    local s = {}
    for i, v in ipairs(t) do
        s[i] = encode(v)
    end
    return '[' .. table.concat(s, ',') .. ']'
end

local function encode_table (t)
    local s = {}
    local i = 0
    for k, v in pairs(t) do
        i = i + 1
        s[i] = encode_string(k) .. ':' .. encode(v)
    end
    return '{' .. table.concat(s, ',') .. '}'
end

function encode (v)
    local t = type(v)
    if t == 'number' or t == 'boolean' then
        return tostring(v)
    end
    if t == 'string' then
        return encode_string(v)
    end
    if t == 'table' then
        if is_array(v) then
            return encode_array(v)
        end
        return encode_table(v)
    end
    if t == 'nil' then
        return 'null'
    end
    error('Unsupported data type: ' .. t)
end

local index = 1
local source
local tokens = {
    ['{'] = 'begin-object',
    ['}'] = 'end-object',
    ['['] = 'begin-array',
    [']'] = 'end-array',
    [':'] = 'name-separator',
    [','] = 'value-separator'
}

local function next_char ()
    local c = source:sub(index, index)
    index = index + 1
    return c
end

local function skip_whitespace ()
    local c = next_char()
    while c ~= '' do
        if c > ' ' then
            index = index - 1
            return c
        end
        c = next_char()
    end
    return c
end

local function get_token ()
    local c = skip_whitespace()
    if c == '' then
        return 'end-of-source'
    end
    if tokens[c] then
        return tokens[c]
    end
    if c == '"' then
        local s = {}
        c = next_char()
        while c ~= '"' do
            if c == '\\' then
                c = next_char()
                if c == '"' or c == '\\' or c == '/' then
                    -- do nothing
                elseif c == 'b' then
                    c = '\b'
                elseif c == 'f' then
                    c = '\f'
                elseif c == 'n' then
                    c = '\n'
                elseif c == 'r' then
                    c = '\r'
                elseif c == 't' then
                    c = '\t'
                elseif c == 'u' then
                    local hex = source:sub(index, index + 3)
                    index = index + 4
                    c = index
                    error('unimplemented Unicode escape')
                else
                    error('Bad escape')
                end
            elseif c == '\n' or c == '\r' or c == '' then
                error('Bad string')
            end
            table.insert(s, c)
            c = next_char()
        end
        return table.concat(s), 'string'
    end
    if c == '-' or (c >= '0' and c <= '9') then
        local s = {}
        if c == '-' then
            table.insert(s, c)
            c = next_char()
        end
        if c == '0' then
            table.insert(s, c)
            c = next_char()
        elseif c >= '1' and c <= '9' then
            while c >= '0' and c <= '9' do
                table.insert(s, c)
                c = next_char()
            end
        else
            error('Bad number')
        end
        if c == '.' then
            table.insert(s, c)
            c = next_char()
            if c >= '0' and c <= '9' then
                while c >= '0' and c <= '9' do
                    table.insert(s, c)
                    c = next_char()
                end
            else
                error('Bad number')
            end
        end
        if c == 'e' or c == 'E' then
            table.insert(s, c)
            c = next_char()
            if c == '-' or c == '+' then
                table.insert(s, c)
                c = next_char()
            end
            if c >= '0' and c <= '9' then
                while c >= '0' and c <= '9' do
                    table.insert(s, c)
                    c = next_char()
                end
            else
                error('Bad number')
            end
        end
        index = index - 1
        return tonumber(table.concat(s)), 'number'
    end
    if c >= 'a' and c <= 'z' then
        local s = c
        index = index - 1
        local i = index
        while c >= 'a' and c <= 'z' do
            c = next_char()
        end
        s = source:sub(i, index - 2)
        index = index - 1
        if s == 'true' then
            return true, 'literal'
        end
        if s == 'false' then
            return false, 'literal'
        end
        if s == 'null' then
            return nil, 'literal'
        end
        error('Bad literal')
    end
    error('Bad token')
end

local look
local type_of_look

local function next_look ()
    look, type_of_look = get_token()
end

local function array ()
    local a = {}
    next_look()
    if look == ']' then
        return a
    end
    while look ~= '' do
        table.insert(a, value())
        next_look()
        if look == ']' then
            return a
        end
        if look ~= ',' then
            error('Bad array')
        end
        next_look()
    end
end

local function object ()
    local o = {}
    next_look()
    if look == '}' then
        return o
    end
    while look ~= '' do
        if type_of_look ~= 'string' then
            error('Bad object')
        end
        local k = look
        next_look()
        if look ~= ':' then
            error('Bad object')
        end
        next_look()
        o[k] = value()
        next_look()
        if look == '}' then
            return o
        end
        if look ~= ',' then
            error('Bad object')
        end
        next_look()
    end
end

local function value ()
    if type_of_look == 'string' or type_of_look == 'number' or type_of_look == 'literal' then
        local v = look
        return v
    end
    if look == '[' then
        return array()
    end
    if look == '{' then
        return object()
    end
    error('Bad value')
end

function decode (s)
    index = 1
    source = s
    next_look()
    local v = value()
    next_look()
    if look ~= 'end-of-source' then
        error('Syntax error')
    end
    return v
end

return {
    encode = encode,
    decode = decode
}