local LrHttp = import 'LrHttp'
local JSON   = require 'JSONbkp'

local DavionsAPI = {}

-- ============================================================
-- URLs (Supabase)
-- ============================================================
local BASE_URL = "https://pjcegphrngpedujeatrl.supabase.co/functions/v1"

DavionsAPI.AUTHENTICATE    = BASE_URL .. "/davions-connect"
DavionsAPI.CREATE_GALLERY  = BASE_URL .. "/create-gallery"
DavionsAPI.ADD_PHOTO       = BASE_URL .. "/add-photo"
DavionsAPI.UPDATE_GALLERY  = BASE_URL .. "/update-gallery"
DavionsAPI.DELETE_PHOTO    = BASE_URL .. "/delete-photo"
DavionsAPI.DELETE_GALLERY  = BASE_URL .. "/delete-gallery"
DavionsAPI.GET_GALLERY_ID  = BASE_URL .. "/get-gallery-id"

-- ============================================================
-- Helpers
-- ============================================================
local function authHeaders(token)
    return {
        { field = "Content-Type",  value = "application/json" },
        { field = "Authorization", value = "Bearer " .. (token or "") },
    }
end

local function jsonPost(url, body, token, timeout)
    local headers = token and authHeaders(token)
        or {{ field = "Content-Type", value = "application/json" }}
    local response, hdrs = LrHttp.post(url, body, headers, timeout or 15)
    return response, hdrs
end

-- ============================================================
-- Autentica via email + senha
-- Retorna: data (tabela com photographer_id, email, token) ou nil, errmsg
-- ============================================================
function DavionsAPI.authenticate(email, password)
    if not email    or email    == "" then return nil, "E-mail não informado." end
    if not password or password == "" then return nil, "Senha não informada." end

    local body = JSON.encode({ email = email, password = password })
    local response = LrHttp.post(DavionsAPI.AUTHENTICATE, body,
        {{ field = "Content-Type", value = "application/json" }}, 15)

    if not response then
        return nil, "Não foi possível conectar ao servidor."
    end

    local ok, data = pcall(JSON.decode, response)
    if not ok or not data then
        return nil, "Resposta do servidor inválida."
    end

    -- Esperado: { status="success", response={photographer_id, email}, token="eyJ..." }
    if data.status ~= "success" or not data.token then
        local msg = (data.message or data.error or "Credenciais inválidas.")
        return nil, msg
    end

    return {
        photographer_id = data.response and data.response.photographer_id,
        email           = data.response and data.response.email,
        token           = data.token,
    }
end

-- ============================================================
-- Cria uma galeria
-- ============================================================
function DavionsAPI.createGallery(token, photographerId, name, galleryType)
    local body = JSON.encode({
        photographer_id = photographerId,
        gallery_name    = name,
        gallery_type    = galleryType or "proof",
    })
    local response, hdrs = jsonPost(DavionsAPI.CREATE_GALLERY, body, token)
    if not response then return nil, "Sem resposta do servidor." end

    local ok, data = pcall(JSON.decode, response)
    if ok and data then return data end
    return nil, "Resposta inválida ao criar galeria."
end

-- ============================================================
-- Atualiza nome de uma galeria
-- ============================================================
function DavionsAPI.updateGallery(token, galleryId, newName, photographerId)
    local body = JSON.encode({
        gallery_id      = galleryId,
        gallery_name    = newName,
        photographer_id = photographerId,
    })
    local response, hdrs = jsonPost(DavionsAPI.UPDATE_GALLERY, body, token)
    local status = hdrs and hdrs.status
    return (status and status >= 200 and status < 300), status
end

-- ============================================================
-- Exclui uma galeria
-- ============================================================
function DavionsAPI.deleteGallery(token, galleryId, photographerId)
    local body = JSON.encode({
        gallery_id      = galleryId,
        photographer_id = photographerId or "",
    })
    local _, hdrs = jsonPost(DavionsAPI.DELETE_GALLERY, body, token)
    local status = hdrs and hdrs.status
    return (status and status >= 200 and status < 300), status
end

-- ============================================================
-- Exclui uma foto
-- ============================================================
function DavionsAPI.deletePhoto(token, photoId, photographerId)
    local body = JSON.encode({
        photo_id        = photoId,
        photographer_id = photographerId or "",
    })
    local _, hdrs = jsonPost(DavionsAPI.DELETE_PHOTO, body, token)
    local status = hdrs and hdrs.status
    return (status and status >= 200 and status < 300), status
end

-- ============================================================
-- Busca gallery_id por título (fallback para rename entre sessões)
-- Retorna: gallery_id (string) ou nil, errmsg
-- ============================================================
function DavionsAPI.getGalleryId(token, photographerId, title)
    if not photographerId or photographerId == "" then return nil, "photographer_id não informado." end
    if not title          or title          == "" then return nil, "title não informado." end

    local body = JSON.encode({
        photographer_id = photographerId,
        title           = title,
    })
    local response, hdrs = jsonPost(DavionsAPI.GET_GALLERY_ID, body, token)
    local status = hdrs and hdrs.status

    if not response or not status then
        return nil, "Sem resposta do servidor."
    end
    if status == 404 then
        return nil, "Galeria não encontrada."
    end
    if status < 200 or status >= 300 then
        return nil, "Erro HTTP " .. tostring(status)
    end

    local ok, data = pcall(JSON.decode, response)
    if ok and data and data.gallery_id and data.gallery_id ~= "" then
        return data.gallery_id
    end
    return nil, "gallery_id não encontrado na resposta."
end

return DavionsAPI