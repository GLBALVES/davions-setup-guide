return {
    LrSdkVersion = 8,
    LrPluginName = "Davions Connect",
    LrToolkitIdentifier = 'com.davions.connect',
    VERSION = {
        major = 1,
        minor = 0,
        revision = 0,
    },

    -- ADIÇÃO ESSENCIAL: Permite que o plugin acesse a Internet
    LrInternetAccess = true,
    LrRequiredNetworkAccess = true,  -- Adicionado para garantir acesso à rede

    LrExportServiceProvider = {
        title = "Davions Connect",
        file = "DavionsProvider.lua",

        supportsCustomValidation = true,
        -- Permissão duplicada no ServiceProvider para garantir a compatibilidade
        supportsInternetAccess = true,
        supportsIncrementalPublish = 'only',
        canCreateNewCollection = true,
        canCreateNewCollectionSet = true,
    },

    LrPluginMenuItems = {

    },
}
