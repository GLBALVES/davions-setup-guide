local LrView      = import 'LrView'
local LrTasks     = import 'LrTasks'
local LrDialogs   = import 'LrDialogs'
local LrHttp      = import 'LrHttp'
local LrLogger    = import 'LrLogger'
local LrPrefs     = import 'LrPrefs'
local LrPathUtils = import 'LrPathUtils'
local LrErrors    = import 'LrErrors'
local LrFileUtils    = import 'LrFileUtils'
local LrApplication  = import 'LrApplication'

local log   = LrLogger('DavionsConnect')
log:enable("print")

local bind  = LrView.bind
local prefs = LrPrefs.prefsForPlugin()

-- ============================================================
-- Keys
-- ============================================================
local API_KEY_PREF         = "davions_apiKey"       -- stores the JWT after login
local PHOTOGRAPHER_ID_PREF = "davions_photographerId"
local USER_EMAIL_PREF      = "davions_userEmail"
local USER_PASSWORD_PREF   = "davions_password"     -- never persisted to disk
local STATUS_TEXT_KEY      = "davions_statusText"
local STATUS_COLOR_KEY     = "davions_statusColor"
local COLL_GALLERY_TYPE    = "davions_galleryType"
local COLL_GALLERY_ID      = "davions_galleryId"

local AUTHENTICATION_URL  = "https://pjcegphrngpedujeatrl.supabase.co/functions/v1/davions-connect"
local CREATE_GALLERY_URL  = "https://pjcegphrngpedujeatrl.supabase.co/functions/v1/create-gallery"
local ADD_PHOTO_URL       = "https://pjcegphrngpedujeatrl.supabase.co/functions/v1/add-photo"
local UPDATE_GALLERY_URL  = "https://pjcegphrngpedujeatrl.supabase.co/functions/v1/update-gallery"
local DELETE_PHOTO_URL    = "https://pjcegphrngpedujeatrl.supabase.co/functions/v1/delete-photo"
local DELETE_GALLERY_URL  = "https://pjcegphrngpedujeatrl.supabase.co/functions/v1/delete-gallery"
local GET_GALLERY_ID_URL  = "https://pjcegphrngpedujeatrl.supabase.co/functions/v1/get-gallery-id"


-- ============================================================
-- Helpers
-- ============================================================
local function parseId(json)       return json and json:match('"photographer_id"%s*:%s*"([^"]+)"') end
local function parseEmail(json)    return json and json:match('"email"%s*:%s*"([^"]+)"') end
local function parseToken(json)    return json and json:match('"token"%s*:%s*"([^"]+)"') end
local function parseUniqueId(json) return json and json:match('"unique_id"%s*:%s*"([^"]+)"') end
local function parsePhotoId(json)  return json and json:match('"photo_id"%s*:%s*"([^"]+)"') end

local function updateStatus(propertyTable, pId, pEmail)
    if pId and pId ~= "" then
        local display = (pEmail and pEmail ~= "") and pEmail or pId
        propertyTable[STATUS_TEXT_KEY]  = "Connected: " .. display
        propertyTable[STATUS_COLOR_KEY] = "green"
    else
        propertyTable[STATUS_TEXT_KEY]  = "Not Authenticated"
        propertyTable[STATUS_COLOR_KEY] = "#bb0000"
    end
end

local function authHeaders(token)
    return {
        { field = "Content-Type",  value = "application/json" },
        { field = "Authorization", value = "Bearer " .. (token or "") },
    }
end

local function jsonEscape(s)
    s = tostring(s or "")
    s = s:gsub('\\', '\\\\')
    s = s:gsub('"',  '\\"')
    s = s:gsub('\n', '\\n')
    s = s:gsub('\r', '\\r')
    s = s:gsub('\t', '\\t')
    return s
end

-- ============================================================
-- Provider
-- ============================================================
local DavionsProvider = {
    title                      = "Davions Connect",
    supportsIncrementalPublish = 'only',
    small_icon                 = 'small_davionsconnect.png',

    exportPresetFields = {
        { key = API_KEY_PREF,         default = "" },
        { key = PHOTOGRAPHER_ID_PREF, default = "" },
        { key = USER_EMAIL_PREF,      default = "" },
        { key = USER_PASSWORD_PREF,   default = "" },
    },

    startDialog = function(propertyTable)
        prefs.photographerId = propertyTable[PHOTOGRAPHER_ID_PREF] or ""
        prefs.apiKey         = propertyTable[API_KEY_PREF] or ""
        updateStatus(propertyTable, propertyTable[PHOTOGRAPHER_ID_PREF], propertyTable[USER_EMAIL_PREF])
    end,

    sectionsForTopOfDialog = function(f, propertyTable)
        local vf = f or LrView.viewFactory()
        updateStatus(propertyTable, propertyTable[PHOTOGRAPHER_ID_PREF], propertyTable[USER_EMAIL_PREF])

        return {{
            title = "Davions Account",
            vf:column {
                spacing        = vf:control_spacing(),
                bind_to_object = propertyTable,

                vf:row {
                    vf:spacer  { fill_horizontal = 1 },
                    vf:picture { value = _PLUGIN.path .. "/DavionsConnect_250x50.png" },
                    vf:spacer  { fill_horizontal = 1 },
                },
                vf:separator {},
                vf:row {
                    vf:static_text { title = "Email:", width_in_chars = 15, alignment = "right" },
                    vf:edit_field {
                        value = bind(USER_EMAIL_PREF), width_in_chars = 35,
                        validate = function(view, value)
                            propertyTable[USER_EMAIL_PREF] = value
                            return true, value
                        end,
                    },
                },
                vf:row {
                    vf:static_text { title = "Password:", width_in_chars = 15, alignment = "right" },
                    vf:password_field {
                        value = bind(USER_PASSWORD_PREF), width_in_chars = 35,
                    },
                },
                vf:row {
                    vf:static_text { title = "Status:", width_in_chars = 15, alignment = "right" },
                    vf:static_text {
                        title      = bind(STATUS_TEXT_KEY),
                        font       = "<system/bold>",
                        text_color = bind(STATUS_COLOR_KEY),
                    },
                },
                vf:spacer { height = 10 },
                vf:row {
                    vf:spacer { fill_horizontal = 1 },
                    vf:push_button {
                        title = "Authenticate Account", width = 180,
                        action = function()
                            LrTasks.startAsyncTask(function()
                                local email    = propertyTable[USER_EMAIL_PREF]
                                local password = propertyTable[USER_PASSWORD_PREF]
                                if not email or email == "" then
                                    LrDialogs.message("Davions", "Please enter your email.")
                                    return
                                end
                                if not password or password == "" then
                                    LrDialogs.message("Davions", "Please enter your password.")
                                    return
                                end
                                LrDialogs.showBezel("Authenticating...", 2)
                                local body = string.format(
                                    '{"email":"%s","password":"%s"}', email, password)
                                local result = LrHttp.post(AUTHENTICATION_URL, body,
                                    {{ field = "Content-Type", value = "application/json" }}, 10)
                                if result then
                                    local jwt    = parseToken(result)
                                    local pId    = parseId(result)
                                    local pEmail = parseEmail(result)
                                    if jwt and pId then
                                        propertyTable[API_KEY_PREF]         = jwt
                                        propertyTable[PHOTOGRAPHER_ID_PREF] = pId
                                        propertyTable[USER_EMAIL_PREF]      = pEmail or email
                                        propertyTable[USER_PASSWORD_PREF]   = ""   -- clear from UI
                                        prefs.photographerId                = pId
                                        prefs.apiKey                        = jwt
                                        updateStatus(propertyTable, pId, pEmail or email)
                                        LrDialogs.message("Davions",
                                            "Authenticated!\nAccount: " .. (pEmail or pId))
                                    else
                                        LrDialogs.message("Davions",
                                            "Authentication failed: invalid credentials or unexpected response.\n\n" ..
                                            tostring(result))
                                    end
                                else
                                    LrDialogs.message("Davions", "Error: No response from server.")
                                end
                            end)
                        end,
                    },
                    vf:push_button {
                        title = "Logout",
                        action = function()
                            propertyTable[API_KEY_PREF]         = ""
                            propertyTable[PHOTOGRAPHER_ID_PREF] = ""
                            propertyTable[USER_EMAIL_PREF]      = ""
                            propertyTable[USER_PASSWORD_PREF]   = ""
                            prefs.photographerId                = ""
                            prefs.apiKey                        = ""
                            updateStatus(propertyTable, nil, nil)
                        end,
                    },
                    vf:spacer { fill_horizontal = 1 },
                },
            }
        }}
    end,

    viewForCollectionSettings = function(f, publishSettings, info)
        local vf       = f
        local settings = info.collectionSettings

        if not settings[COLL_GALLERY_TYPE] or settings[COLL_GALLERY_TYPE] == "" then
            settings[COLL_GALLERY_TYPE] = "proof"
        end

        return vf:column {
            spacing        = vf:control_spacing(),
            bind_to_object = settings,
            vf:row {
                vf:static_text { title = "Gallery Type:", width_in_chars = 14, alignment = "right" },
                vf:popup_menu {
                    value = bind(COLL_GALLERY_TYPE),
                    items = {
                        { title = "Proof Gallery", value = "proof" },
                        { title = "Final Gallery", value = "final" },
                    },
                },
            },
            vf:row {
                vf:static_text { title = "Gallery ID:", width_in_chars = 14, alignment = "right" },
                vf:static_text {
                    title = bind {
                        key = COLL_GALLERY_ID,
                        transform = function(v)
                            return (v and v ~= "") and v or "Not created yet"
                        end,
                    },
                    text_color = bind {
                        key = COLL_GALLERY_ID,
                        transform = function(v)
                            return (v and v ~= "") and "green" or "#888888"
                        end,
                    },
                },
            },
        }
    end,

    -- ============================================================
    -- endDialogForCollectionSettings
    -- Always cache gallery_id by collection name in prefs.
    -- This is the only reliable bridge to processRenderedPhotos,
    -- since publishedCollectionInfo.collectionSettings is nil at publish time.
    -- ============================================================
    endDialogForCollectionSettings = function(publishSettings, info)
        log:trace("=== endDialogForCollectionSettings ===")
        if not info or info.why ~= "ok" then return end

        local settings    = info.collectionSettings
        local existingId  = settings and settings[COLL_GALLERY_ID]
        local galleryName = info.name or ""

        -- Collection already has an ID: check if name changed and update server if needed
        if existingId and existingId ~= "" then
            log:trace("  Already has ID: " .. existingId)

            local token          = (publishSettings and publishSettings[API_KEY_PREF]) or prefs.apiKey or ""
            local photographerId = (publishSettings and publishSettings[PHOTOGRAPHER_ID_PREF])
                or prefs.photographerId or ""
            local oldCachedName  = prefs["galleryName_" .. existingId] or ""

            if galleryName ~= "" and galleryName ~= oldCachedName then
                log:trace("  Name changed: '" .. oldCachedName .. "' ? '" .. galleryName .. "' � calling update-gallery")
                LrTasks.startAsyncTask(function()
                    local body = string.format(
                        '{"gallery_id":"%s","gallery_name":"%s","photographer_id":"%s"}',
                        jsonEscape(existingId), jsonEscape(galleryName), jsonEscape(photographerId)
                    )
                    local result, hdrs = LrHttp.post(UPDATE_GALLERY_URL, body, authHeaders(token), 15)
                    local status = hdrs and hdrs.status
                    log:trace("  update-gallery HTTP " .. tostring(status) .. " | " .. tostring(result))
                end)
                -- Update name cache immediately (don't wait for async)
                prefs["galleryName_" .. existingId]    = galleryName
            end

            -- Refresh all ID caches with current name
            if galleryName ~= "" then
                prefs["galleryId_name_" .. galleryName] = existingId
                log:trace("  Cache refreshed for name=" .. galleryName)
            end

            -- Refresh localId cache
            local publishedColl = info.publishedCollection
            local localId = publishedColl and publishedColl.localIdentifier
            if localId then
                prefs["galleryId_localId_" .. tostring(localId)] = existingId
                prefs["galleryId_" .. tostring(localId)]         = existingId
            end

            return
        end

        -- New collection: create gallery on Davions
        local photographerId = (publishSettings and publishSettings[PHOTOGRAPHER_ID_PREF])
        if not photographerId or photographerId == "" then
            photographerId = prefs.photographerId or ""
        end

        if not photographerId or photographerId == "" then
            LrDialogs.message("Davions",
                "You must authenticate before creating a gallery.\n" ..
                "Open the Publishing Manager and authenticate first.", "critical")
            return
        end

        local galleryType = (settings and settings[COLL_GALLERY_TYPE]) or "proof"
        local uid         = nil
        local done        = false

        LrTasks.startAsyncTask(function()
            local body = string.format(
                '{"photographer_id":"%s","gallery_name":"%s","gallery_type":"%s"}',
                jsonEscape(photographerId), jsonEscape(galleryName), jsonEscape(galleryType)
            )
            local token = publishSettings and publishSettings[API_KEY_PREF] or prefs.apiKey or ""
            local result = LrHttp.post(CREATE_GALLERY_URL, body,
                authHeaders(token), 15)
            uid  = result and parseUniqueId(result)
            done = true
        end)

        local waited = 0
        while not done and waited < 20 do
            LrTasks.sleep(0.1)
            waited = waited + 0.1
        end

        if not uid then
            LrDialogs.message("Davions",
                "Gallery could not be created or no ID was returned.\nPlease try again.", "critical")
            return
        end

        settings[COLL_GALLERY_ID] = uid

        -- Cache by name in prefs � used by processRenderedPhotos
        if galleryName ~= "" then
            prefs["galleryId_name_" .. galleryName] = uid
            prefs["galleryName_" .. uid]            = galleryName  -- reverse cache for rename detection
            log:trace("  gallery_id cached for name=" .. galleryName)
        end

        -- Cache by localId � most reliable fallback for rename across sessions
        local publishedColl = info.publishedCollection
        local localId = publishedColl and publishedColl.localIdentifier
        if localId then
            prefs["galleryId_localId_" .. tostring(localId)] = uid
            prefs["galleryId_" .. tostring(localId)]         = uid
            log:trace("  gallery_id cached for localId=" .. tostring(localId))
        end

        LrDialogs.message("Davions",
            "Gallery created successfully!\nType: " .. galleryType .. "\nID: " .. uid)
    end,

    -- ============================================================
    -- processRenderedPhotos
    -- Reads gallery_id exclusively from prefs cache (by collection name).
    -- No auto-create. If not found, instructs user to Edit the collection.
    -- ============================================================
    processRenderedPhotos = function(functionContext, exportContext)
        log:trace("=== processRenderedPhotos ===")

        local exportSession           = exportContext.exportSession
        local publishSettings         = exportContext.propertyTable
        local publishedCollectionInfo = exportContext.publishedCollectionInfo

        -- Authenticate check
        local photographerId = publishSettings[PHOTOGRAPHER_ID_PREF]
        if not photographerId or photographerId == "" then
            LrDialogs.message("Davions",
                "Not authenticated. Please open the Publishing Manager and authenticate first.",
                "critical")
            LrErrors.throwUserError("Not authenticated.")
            return
        end

        -- Get gallery_id from prefs by collection name
        local collName  = publishedCollectionInfo and publishedCollectionInfo.name
        local galleryId = (collName and collName ~= "") and prefs["galleryId_name_" .. collName] or nil

        log:trace("  collName=" .. tostring(collName))
        log:trace("  galleryId=" .. tostring(galleryId))

        if not galleryId or galleryId == "" then
            LrDialogs.message("Davions",
                "Gallery ID not found for collection '" .. tostring(collName) .. "'.\n\n" ..
                "Right-click the collection, choose Edit, then click OK to register the gallery.",
                "critical")
            LrErrors.throwUserError("Missing gallery ID.")
            return
        end

        -- Persist galleryId by localId so rename works across sessions
        local publishedColl = publishedCollectionInfo and publishedCollectionInfo.publishedCollection
        local collLocalId   = publishedColl and publishedColl.localIdentifier
        if collLocalId and galleryId then
            prefs["galleryId_localId_" .. tostring(collLocalId)] = galleryId
            prefs["galleryId_" .. tostring(collLocalId)]         = galleryId
            log:trace("  galleryId cached by localId=" .. tostring(collLocalId))
        end

        -- Upload
        local nPhotos       = exportSession:countRenditions()
        local progressScope = exportContext:configureProgress({
            title = "Uploading " .. nPhotos .. " photo(s) to Davions...",
        })

        local uploaded = 0
        local failed   = 0
        local photoNum = 0

        -- Upload loop
        for i, rendition in exportContext:renditions() do
            if progressScope:isCanceled() then break end
            photoNum = photoNum + 1

            local success, pathOrMessage = rendition:waitForRender()
            if not success then
                rendition:uploadFailed("Render failed: " .. tostring(pathOrMessage))
                failed = failed + 1
            else
                local filePath = pathOrMessage
                local fileName = LrPathUtils.leafName(filePath)

                progressScope:setCaption("Uploading " .. fileName .. " (" .. photoNum .. "/" .. nPhotos .. ")")
                log:trace("  Uploading: " .. fileName)

                -- Send as multipart/form-data (binary) � no base64 encoding needed
                local mimeChunks = {
                    { name = "gallery_id",      value = galleryId },
                    { name = "photographer_id", value = photographerId },
                    { name = "photo_name",      value = fileName },
                    { name = "photo",           fileName = fileName,
                      filePath = filePath,      contentType = "image/jpeg" },
                }

                local token = publishSettings[API_KEY_PREF] or ""
                local httpResult, httpHdrs = LrHttp.postMultipart(ADD_PHOTO_URL, mimeChunks,
                    {{ field = "Authorization", value = "Bearer " .. token }}, 120)

                local httpStatus = httpHdrs and httpHdrs.status
                log:trace("  [" .. fileName .. "] HTTP " .. tostring(httpStatus))

                if httpStatus and httpStatus >= 200 and httpStatus < 300 then
                    -- Only mark as published AFTER server confirms success
                    local photoId = httpResult and parsePhotoId(httpResult)
                    local idToRecord = (photoId and photoId ~= "") and photoId or fileName
                    -- recordPublishedPhotoId must be called within the export/publish context
                    -- that Lightroom provides � no separate withWriteAccessDo needed here
                    local recordOk, recordErr = pcall(function()
                        rendition:recordPublishedPhotoId(idToRecord)
                    end)
                    if recordOk then
                        uploaded = uploaded + 1
                        log:trace("  OK � recorded photoId: " .. tostring(idToRecord))
                    else
                        -- Fallback: try via catalog write access
                        log:trace("  Direct record failed, trying catalog write: " .. tostring(recordErr))
                        local catalog = LrApplication.activeCatalog()
                        local writeOk, writeErr = pcall(function()
                            catalog:withWriteAccessDo("Davions: record photo ID", function()
                                rendition:recordPublishedPhotoId(idToRecord)
                            end, { timeout = 10 })
                        end)
                        if writeOk then
                            uploaded = uploaded + 1
                            log:trace("  OK (via catalog) � recorded photoId: " .. tostring(idToRecord))
                        else
                            log:trace("  WARNING: could not record photo ID: " .. tostring(writeErr))
                            -- Still count as uploaded since server accepted it
                            uploaded = uploaded + 1
                        end
                    end
                else
                    local errMsg = "Upload failed (HTTP " .. tostring(httpStatus) .. ")"
                    log:trace("  FAIL: " .. errMsg .. " | " .. tostring(httpResult))
                    rendition:uploadFailed(errMsg)
                    failed = failed + 1
                end

                progressScope:setPortionComplete(photoNum, nPhotos)
            end
        end
        log:trace("  Done. Uploaded=" .. uploaded .. " Failed=" .. failed)

        if failed > 0 then
            LrDialogs.message("Davions",
                "Upload complete with errors.\n" ..
                uploaded .. " photo(s) uploaded successfully.\n" ..
                failed   .. " photo(s) failed.")
        end
    end,

    deletePublishedCollection = function(publishSettings, info)
        log:trace("=== deletePublishedCollection ===")

        local publishedColl = info.publishedCollection
        local localId       = publishedColl and publishedColl.localIdentifier
        local galleryId     = nil

        -- Source 1: getCollectionInfoSummary
        if publishedColl then
            local ok, collInfo = pcall(function() return publishedColl:getCollectionInfoSummary() end)
            if ok and collInfo and collInfo.collectionSettings then
                galleryId = collInfo.collectionSettings[COLL_GALLERY_ID]
            end
        end

        -- Source 2: prefs by localId
        if (not galleryId or galleryId == "") and localId then
            galleryId = prefs["galleryId_" .. tostring(localId)]
        end

        -- Source 3: prefs by name
        if (not galleryId or galleryId == "") and info.name then
            galleryId = prefs["galleryId_name_" .. info.name]
        end

        log:trace("  galleryId=" .. tostring(galleryId))

        if not galleryId or galleryId == "" then
            log:trace("  No gallery ID found, skipping delete.")
            return
        end

        local token = publishSettings and publishSettings[API_KEY_PREF] or prefs.apiKey or ""
        local photographerId = (publishSettings and publishSettings[PHOTOGRAPHER_ID_PREF])
            or prefs.photographerId or ""
        local body = string.format(
            '{"gallery_id":"%s","photographer_id":"%s"}',
            jsonEscape(galleryId), jsonEscape(photographerId)
        )
        -- Call directly on main thread � deletePublishedCollection is NOT inside an async task
        local _, hdrs = LrHttp.post(DELETE_GALLERY_URL, body, authHeaders(token), 15)
        log:trace("  delete_gallery HTTP " .. tostring(hdrs and hdrs.status))

        -- Clean up prefs cache
        if localId then
            prefs["galleryId_" .. tostring(localId)] = nil
        end
        if info.name then
            prefs["galleryId_name_" .. info.name] = nil
        end

        log:trace("  Gallery deleted and cache cleared.")
    end,

    deletePhotosFromPublishedCollection = function(publishSettings, arrayOfPhotoIds, deletedCallback)
        log:trace("=== deletePhotosFromPublishedCollection ===")
        log:trace("  photos to delete: " .. tostring(#arrayOfPhotoIds))

        local token   = publishSettings and publishSettings[API_KEY_PREF] or prefs.apiKey or ""
        local headers = authHeaders(token)

        for _, photoId in ipairs(arrayOfPhotoIds) do
            log:trace("  deleting photoId: " .. tostring(photoId))

            local photographerId = (publishSettings and publishSettings[PHOTOGRAPHER_ID_PREF])
                or prefs.photographerId or ""
            local body = string.format(
                '{"photo_id":"%s","photographer_id":"%s"}',
                tostring(photoId), jsonEscape(photographerId)
            )
            -- Call directly on main thread � deletePhotosFromPublishedCollection is NOT inside an async task
            local _, hdrs = LrHttp.post(DELETE_PHOTO_URL, body, headers, 15)
            local status = hdrs and hdrs.status

            log:trace("  delete HTTP " .. tostring(status))

            if deletedCallback then
                deletedCallback(photoId)
            end
        end
    end,

    renamePublishedCollection = function(publishSettings, info)
        log:trace("=== renamePublishedCollection ===")

        local newName       = info.name or ""
        local publishedColl = info.publishedCollection
        local localId       = publishedColl and publishedColl.localIdentifier
        local galleryId     = nil

        -- Source 1: getCollectionInfoSummary (most reliable � settings saved by LR)
        if publishedColl then
            local ok, collInfo = pcall(function() return publishedColl:getCollectionInfoSummary() end)
            if ok and collInfo and collInfo.collectionSettings then
                galleryId = collInfo.collectionSettings[COLL_GALLERY_ID]
                log:trace("  galleryId from getCollectionInfoSummary: " .. tostring(galleryId))
            end
        end

        -- Source 2: prefs by localId (legacy key)
        if (not galleryId or galleryId == "") and localId then
            galleryId = prefs["galleryId_" .. tostring(localId)]
            log:trace("  galleryId from prefs galleryId_localId (legacy): " .. tostring(galleryId))
        end

        -- Source 3: prefs by localId (new key format)
        if (not galleryId or galleryId == "") and localId then
            galleryId = prefs["galleryId_localId_" .. tostring(localId)]
            log:trace("  galleryId from prefs galleryId_localId_: " .. tostring(galleryId))
        end

        -- Source 4: prefs by OLD name � getName() still returns the old name at this point
        if (not galleryId or galleryId == "") and publishedColl then
            local ok, oldName = pcall(function() return publishedColl:getName() end)
            if ok and oldName and oldName ~= "" then
                galleryId = prefs["galleryId_name_" .. oldName]
                log:trace("  galleryId from prefs oldName=" .. tostring(oldName) .. ": " .. tostring(galleryId))
            end
        end

        -- Source 5: API lookup by title (last resort � survives reinstall and new sessions)
        if (not galleryId or galleryId == "") then
            log:trace("  All local sources failed � trying API lookup by title")
            local photographerId = (publishSettings and publishSettings[PHOTOGRAPHER_ID_PREF])
                or prefs.photographerId or ""
            local token = (publishSettings and publishSettings[API_KEY_PREF]) or prefs.apiKey or ""
            if photographerId ~= "" and token ~= "" then
                -- NEVER use newName here � it does not exist in the DB yet.
                -- getName() already returns newName at this point (LR renames in memory before callback),
                -- so it is not a reliable source for the old title either.
                -- Only attempt the API call if we can determine a title that is genuinely the OLD name.
                local namesToTry = {}
                if publishedColl then
                    local ok2, oldName = pcall(function() return publishedColl:getName() end)
                    -- Only add if it differs from newName (i.e. LR hasn't overwritten it yet in this env)
                    if ok2 and oldName and oldName ~= "" and oldName ~= newName then
                        table.insert(namesToTry, oldName)
                    end
                end

                if #namesToTry == 0 then
                    log:trace("  Source 5 skipped � cannot determine old title reliably after LR rename")
                else
                    for _, titleToTry in ipairs(namesToTry) do
                        local body = string.format(
                            '{"photographer_id":"%s","title":"%s"}',
                            jsonEscape(photographerId), jsonEscape(titleToTry)
                        )
                        local apiResult = LrHttp.post(GET_GALLERY_ID_URL, body, authHeaders(token), 10)
                        log:trace("  API lookup response: " .. tostring(apiResult))
                        if apiResult then
                            local found = apiResult:match('"gallery_id"%s*:%s*"([^"]+)"')
                            if found and found ~= "" then
                                galleryId = found
                                log:trace("  galleryId from API (title=" .. titleToTry .. "): " .. galleryId)
                                if localId then
                                    prefs["galleryId_localId_" .. tostring(localId)] = galleryId
                                    prefs["galleryId_" .. tostring(localId)]         = galleryId
                                end
                                prefs["galleryId_name_" .. titleToTry] = galleryId
                                break
                            end
                        end
                    end
                end
            end
        end

        log:trace("  newName=" .. newName .. " | galleryId=" .. tostring(galleryId))

        if not galleryId or galleryId == "" then
            log:trace("  No gallery ID found, aborting rename.")
            LrDialogs.message("Davions",
                "Could not find the gallery ID for '" .. tostring(newName) .. "'.\n\n" ..
                "Right-click the collection ? Edit Collection ? click OK to re-register it, then rename again.",
                "critical")
            return
        end

        local photographerId = (publishSettings and publishSettings[PHOTOGRAPHER_ID_PREF])
        if not photographerId or photographerId == "" then
            photographerId = prefs.photographerId or ""
        end

        local token = publishSettings and publishSettings[API_KEY_PREF] or prefs.apiKey or ""
        local body = string.format(
            '{"gallery_id":"%s","gallery_name":"%s","photographer_id":"%s"}',
            jsonEscape(galleryId), jsonEscape(newName), jsonEscape(photographerId)
        )
        -- Call directly on main thread � renamePublishedCollection is NOT inside an async task
        local result, hdrs = LrHttp.post(UPDATE_GALLERY_URL, body, authHeaders(token), 15)
        local httpStatus = hdrs and hdrs.status
        log:trace("  update_gallery HTTP " .. tostring(httpStatus) .. " | " .. tostring(result))
        local ok = (httpStatus and httpStatus >= 200 and httpStatus < 300)

        if ok then
            -- Update all prefs cache keys with new name
            prefs["galleryId_name_" .. newName] = galleryId
            if localId then
                prefs["galleryId_" .. tostring(localId)]         = galleryId
                prefs["galleryId_localId_" .. tostring(localId)] = galleryId
            end
            log:trace("  Cache updated: " .. newName .. " = " .. galleryId)
        else
            log:trace("  Rename failed or timed out.")
        end
    end,
}

return DavionsProvider